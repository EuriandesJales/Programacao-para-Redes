variable "argocd_chart_version" { type = string }
variable "gitops_repo_url" { type = string }

resource "kubernetes_namespace" "argocd" {
  metadata {
    name = "argocd"
  }
}

# Terraform instala apenas o *controlador* ArgoCD. A partir daqui, todo
# objeto de aplicação Kubernetes é gerenciado via Git + ArgoCD, nunca mais
# via `terraform apply` ou `kubectl apply` manual — fronteira dura entre
# "infraestrutura" (Terraform) e "estado de aplicação" (GitOps).
resource "helm_release" "argocd" {
  name       = "argocd"
  repository = "https://argoproj.github.io/argo-helm"
  chart      = "argo-cd"
  version    = var.argocd_chart_version
  namespace  = kubernetes_namespace.argocd.metadata[0].name

  set {
    name  = "configs.params.server\\.insecure"
    value = "false"
  }

  # Segredo inicial do admin nunca fica no state em texto claro: usamos o
  # backend do Vault (Vault Provider) para gerar e recuperar via referência.
  set_sensitive {
    name  = "configs.secret.argocdServerAdminPassword"
    value = data.vault_generic_secret.argocd_admin.data["bcrypt_hash"]
  }
}

data "vault_generic_secret" "argocd_admin" {
  path = "secret/data/poc-gitops/argocd"
}

# App-of-apps: único objeto que Terraform aplica manualmente no cluster.
# A partir dele, o ArgoCD passa a reconciliar tudo que está em kubernetes/argocd/apps/.
resource "kubernetes_manifest" "root_app" {
  manifest = {
    apiVersion = "argoproj.io/v1alpha1"
    kind       = "Application"
    metadata = {
      name      = "poc-root"
      namespace = "argocd"
    }
    spec = {
      project = "default"
      source = {
        repoURL        = var.gitops_repo_url
        targetRevision = "main"
        path           = "kubernetes/argocd/apps"
      }
      destination = {
        server    = "https://kubernetes.default.svc"
        namespace = "argocd"
      }
      syncPolicy = {
        automated = {
          prune    = true
          selfHeal = true
        }
        syncOptions = ["CreateNamespace=true"]
      }
    }
  }

  depends_on = [helm_release.argocd]
}

output "argocd_namespace" { value = kubernetes_namespace.argocd.metadata[0].name }
