# -----------------------------------------------------------------------------
# Camada 1 — Provisionamento da infraestrutura base (Terraform)
# Orquestra: VPC -> EKS -> bootstrap do ArgoCD via provider helm/kubernetes
# -----------------------------------------------------------------------------

module "vpc" {
  source = "../../modules/vpc"

  name     = var.cluster_name
  vpc_cidr = var.vpc_cidr
}

module "eks" {
  source = "../../modules/eks"

  cluster_name        = var.cluster_name
  cluster_version      = var.cluster_version
  vpc_id               = module.vpc.vpc_id
  private_subnet_ids   = module.vpc.private_subnet_ids
  node_instance_type    = var.node_instance_type
  node_desired_size     = var.node_desired_size
}

# Provider kubernetes/helm autenticam-se dinamicamente contra o cluster
# recém-criado, sem exigir kubeconfig estático em disco no runner de CI.
provider "kubernetes" {
  host                   = module.eks.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks.cluster_ca_certificate)
  token                  = module.eks.cluster_auth_token
}

provider "helm" {
  kubernetes {
    host                   = module.eks.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks.cluster_ca_certificate)
    token                  = module.eks.cluster_auth_token
  }
}

# Camada 4 — Bootstrap do modelo GitOps: instala o ArgoCD e aplica o
# manifesto "app-of-apps" que passa a governar todo o resto do cluster.
module "gitops_bootstrap" {
  source = "../../modules/bootstrap"

  argocd_chart_version = var.argocd_chart_version
  gitops_repo_url      = var.gitops_repo_url

  depends_on = [module.eks]
}
