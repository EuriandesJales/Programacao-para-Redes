variable "aws_region" {
  description = "Região AWS alvo"
  type        = string
  default     = "us-east-1"
}

variable "cluster_name" {
  description = "Nome do cluster EKS"
  type        = string
  default     = "poc-gitops"
}

variable "cluster_version" {
  description = "Versão do Kubernetes"
  type        = string
  default     = "1.30"
}

variable "vpc_cidr" {
  description = "CIDR da VPC"
  type        = string
  default     = "10.20.0.0/16"
}

variable "node_instance_type" {
  description = "Tipo de instância dos worker nodes"
  type        = string
  default     = "t3.medium"
}

variable "node_desired_size" {
  type    = number
  default = 3
}

variable "argocd_chart_version" {
  description = "Versão do Helm chart do ArgoCD"
  type        = string
  default     = "7.6.12"
}

variable "gitops_repo_url" {
  description = "URL do repositório Git usado como fonte de verdade pelo ArgoCD"
  type        = string
  default     = "https://github.com/example-org/poc-gitops.git"
}
