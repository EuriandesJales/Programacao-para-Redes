output "cluster_endpoint" {
  value = module.eks.cluster_endpoint
}

output "node_private_ips" {
  description = "IPs privados dos worker nodes, consumidos pelo inventário dinâmico do Ansible"
  value       = module.eks.node_private_ips
}

output "argocd_namespace" {
  value = module.gitops_bootstrap.argocd_namespace
}
