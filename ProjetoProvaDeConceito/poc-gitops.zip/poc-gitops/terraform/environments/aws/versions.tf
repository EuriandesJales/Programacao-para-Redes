terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.31"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.14"
    }
  }

  # Backend remoto com state locking. Credenciais nunca em texto claro:
  # backend.hcl é gerado a partir de segredos no Vault/CI, nunca commitado.
  backend "s3" {
    key            = "poc-gitops/terraform.tfstate"
    encrypt        = true
    dynamodb_table = "poc-gitops-tf-lock"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project   = "poc-gitops"
      ManagedBy = "terraform"
    }
  }
}
