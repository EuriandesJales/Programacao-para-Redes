from network_state_manager import compute_desired_commands, diff_against_running


DESIRED_STATE = {
    "interfaces": [
        {"name": "eth1", "description": "uplink-to-eks-nodes", "address": "10.30.1.1/24"}
    ],
    "bgp": {
        "asn": 65001,
        "neighbors": [{"address": "10.30.1.2", "remote_asn": 65002}],
    },
}


def test_compute_desired_commands_gera_comandos_esperados():
    commands = compute_desired_commands(DESIRED_STATE)
    assert "set interfaces ethernet eth1 address '10.30.1.1/24'" in commands
    assert any("neighbor 10.30.1.2 remote-as '65002'" in c for c in commands)


def test_diff_e_idempotente_quando_config_ja_aplicada():
    commands = compute_desired_commands(DESIRED_STATE)
    running_config = "\n".join(commands)  # simula dispositivo já convergido
    assert diff_against_running(commands, running_config) == []


def test_diff_detecta_drift_real():
    commands = compute_desired_commands(DESIRED_STATE)
    running_config = "set interfaces ethernet eth1 description 'old-desc'"
    drift = diff_against_running(commands, running_config)
    assert len(drift) == len(commands)
