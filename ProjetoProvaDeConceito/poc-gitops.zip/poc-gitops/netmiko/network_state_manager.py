#!/usr/bin/env python3
"""
network_state_manager.py
=========================

Camada 3 da esteira GitOps — Automação de Infraestrutura de Rede.

Responsabilidades:
  1. Ler o estado DESEJADO (fonte de verdade = Git, via inventory.yaml).
  2. Conectar-se a cada dispositivo (VyOS/FRRouting) via Netmiko.
  3. Coletar o estado ATUAL (`show configuration` / `show running-config`).
  4. Calcular o diff entre desejado e atual (idempotência: sem diff = sem ação).
  5. Em modo `apply`, renderizar templates Jinja2 e empurrar apenas o delta.

Uso:
    python network_state_manager.py --inventory inventory.yaml --mode audit
    python network_state_manager.py --inventory inventory.yaml --mode apply

Códigos de saída (consumidos pelo pipeline de CI como gate):
    0 -> estado conforme (nenhum drift)
    1 -> drift encontrado (e corrigido, se --mode apply)
    2 -> falha de conexão/execução em pelo menos um dispositivo
"""
from __future__ import annotations

import argparse
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import hvac
import yaml
from jinja2 import Environment, FileSystemLoader
from netmiko import ConnectHandler
from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException

LOG = logging.getLogger("network_state_manager")
TEMPLATES_DIR = Path(__file__).parent / "templates"
VAULT_ADDR_ENV = "VAULT_ADDR"


@dataclass
class DeviceResult:
    name: str
    connected: bool
    drift_detected: bool = False
    applied: bool = False
    diff_lines: list[str] = field(default_factory=list)
    error: str | None = None


def load_inventory(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def resolve_credentials(vault_path: str) -> dict[str, str]:
    """Busca credenciais dinâmicas do dispositivo no Vault. Nunca em texto
    claro no repositório — apenas o *caminho* do segredo é versionado."""
    client = hvac.Client()  # autentica via VAULT_TOKEN/VAULT_ADDR do ambiente
    secret = client.secrets.kv.v2.read_secret_version(path=vault_path.replace("secret/data/", ""))
    data = secret["data"]["data"]
    return {"username": data["username"], "password": data["password"]}


def render_template(template_name: str, context: dict[str, Any]) -> str:
    env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)), trim_blocks=True, lstrip_blocks=True)
    template = env.get_template(template_name)
    return template.render(**context)


def compute_desired_commands(desired_state: dict[str, Any]) -> list[str]:
    """Traduz o estado desejado declarativo (YAML) em comandos de linha,
    reaproveitando os mesmos templates Jinja2 usados no `apply`."""
    commands: list[str] = []
    for iface in desired_state.get("interfaces", []):
        commands.extend(render_template("interface.j2", {"iface": iface}).splitlines())

    if "bgp" in desired_state:
        bgp_ctx = {
            "bgp": desired_state["bgp"],
            "router_id": desired_state["interfaces"][0]["address"].split("/")[0],
        }
        commands.extend(render_template("bgp.j2", bgp_ctx).splitlines())

    return [c.strip() for c in commands if c.strip()]


def diff_against_running(desired_commands: list[str], running_config: str) -> list[str]:
    """Diff simples e determinístico: comando desejado é 'drift' se a linha
    (ou seu equivalente set-syntax) não existir literalmente na config atual.
    Suficiente para a PoC; em produção, substituir por parser estruturado
    (ex.: ciscoconfparse / napalm getters) por plataforma."""
    return [cmd for cmd in desired_commands if cmd not in running_config]


def process_device(device: dict[str, Any], mode: str) -> DeviceResult:
    result = DeviceResult(name=device["name"], connected=False)
    try:
        creds = resolve_credentials(device["vault_path"])
    except Exception as exc:  # nosec: falha de Vault é reportada, nunca mascarada
        result.error = f"Falha ao resolver credenciais no Vault: {exc}"
        return result

    connection_params = {
        "device_type": device["device_type"],
        "host": device["host"],
        "username": creds["username"],
        "password": creds["password"],
        "timeout": 15,
    }

    try:
        with ConnectHandler(**connection_params) as conn:
            result.connected = True
            running_config = conn.send_command("show configuration commands")

            desired_commands = compute_desired_commands(device["desired_state"])
            drift = diff_against_running(desired_commands, running_config)

            if not drift:
                LOG.info("[%s] estado conforme — nenhuma ação necessária", device["name"])
                return result

            result.drift_detected = True
            result.diff_lines = drift
            LOG.warning("[%s] drift detectado: %d comando(s) divergente(s)", device["name"], len(drift))

            if mode == "apply":
                conn.send_config_set(drift)
                conn.save_config()
                result.applied = True
                LOG.info("[%s] estado convergido e configuração salva", device["name"])

    except (NetmikoTimeoutException, NetmikoAuthenticationException) as exc:
        result.error = f"Falha de conexão: {exc}"
    except Exception as exc:  # pragma: no cover - guarda genérica para robustez em produção
        result.error = f"Erro inesperado: {exc}"

    return result


def run(inventory_path: Path, mode: str, max_workers: int = 8) -> int:
    inventory = load_inventory(inventory_path)
    devices = inventory.get("devices", [])

    results: list[DeviceResult] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_device, dev, mode): dev["name"] for dev in devices}
        for future in as_completed(futures):
            results.append(future.result())

    any_error = any(r.error for r in results)
    any_drift = any(r.drift_detected for r in results)

    for r in sorted(results, key=lambda x: x.name):
        status = "ERRO" if r.error else ("DRIFT" if r.drift_detected else "OK")
        LOG.info("Resumo [%s] -> %s%s", r.name, status, f" ({r.error})" if r.error else "")

    if any_error:
        return 2
    if any_drift:
        return 1
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--inventory", required=True, type=Path)
    parser.add_argument("--mode", choices=["audit", "apply"], default="audit")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
    )

    exit_code = run(args.inventory, args.mode)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
