# Gerenciamento de Segredos

Princípio único em toda a esteira: **nenhum segredo em texto claro chega ao Git**.
Cada camada usa o mecanismo nativo mais adequado ao seu ecossistema:

| Camada | Mecanismo | Onde vive o segredo real |
|---|---|---|
| Terraform (state, `tfvars`) | **SOPS** (age/KMS) para `terraform.tfvars.enc.yaml`; dados dinâmicos (senha admin do ArgoCD) via `vault_generic_secret` data source | HashiCorp Vault / AWS KMS |
| Ansible | `ansible-vault` para `group_vars/**/vault.yml`; senha do vault injetada no runner via OIDC + Vault | HashiCorp Vault |
| Netmiko | Credenciais de dispositivo nunca no `inventory.yaml` — apenas o **caminho** (`vault_path`); resolvidas em runtime via `hvac` (AppRole) | HashiCorp Vault |
| Kubernetes (segredos de aplicação) | **Sealed Secrets** (Bitnami) — o `SealedSecret` é seguro para versionar; só a chave privada do controller, dentro do cluster, decifra | Cluster (chave privada do controller sealed-secrets) |
| CI (credenciais de nuvem) | **OIDC** (`aws-actions/configure-aws-credentials` com `role-to-assume`) — sem access keys estáticas em `secrets.*` | AWS STS (tokens de curta duração) |
| CI (tokens de terceiros: Vault, ArgoCD) | GitHub Actions *encrypted secrets*, escopo mínimo, rotacionados via Vault AppRole | GitHub Secrets (criptografado) + Vault |

## Regras práticas
1. Nenhum arquivo `*.tfvars`, `*.env` ou `vault.yml` em texto claro é commitado — apenas suas versões `.enc`/cifradas.
2. Pipelines de CI recebem apenas tokens de curto prazo (OIDC/AppRole), nunca credenciais de longa duração.
3. O `apply` de Terraform e Ansible sempre roda atrás de um *GitHub Environment* protegido com aprovação manual.
4. O ArgoCD é o único componente com permissão de escrita ampla dentro do cluster — nenhum pipeline de CI tem `kubectl apply` contra produção.
5. Rotação: credenciais de rede (Netmiko) e de nuvem (Terraform) são dinâmicas via Vault (TTL curto); segredos de aplicação (Sealed Secrets) são rotacionados via novo commit + re-selagem.
